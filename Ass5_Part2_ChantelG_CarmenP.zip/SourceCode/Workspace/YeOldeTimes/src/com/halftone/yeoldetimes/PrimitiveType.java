package com.halftone.yeoldetimes;

/**
 * This enum describes the haltone primitive shape type
 */

public enum PrimitiveType {
	CIRCLE, RECTANGLE, DIAMOND
}
