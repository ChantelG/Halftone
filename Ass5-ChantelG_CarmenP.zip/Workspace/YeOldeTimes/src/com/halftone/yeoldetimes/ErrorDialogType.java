package com.halftone.yeoldetimes;

public enum ErrorDialogType { 
	/**
	 * Types of error dialog
	 */
	NO_IMAGE, NOT_EDITED, NOT_SAVED, GENERAL_ERROR, CONFIRM_FINISH
}