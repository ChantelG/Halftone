package com.halftone.yeoldetimes;

/**
 * Haltone primitive shape type
 */
public enum PrimitiveType {
	CIRCLE, SQUARE, DIAMOND
}
