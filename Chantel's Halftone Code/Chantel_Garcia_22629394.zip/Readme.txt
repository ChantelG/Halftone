Chantel Garcia 
Student Number : 22629394

This readme file contains information about the files submitted.

The Java source code is in the src/ folder.

The runnable JAR file (halftone.jar) is contained in the same directory as this readme file.

The Java binary files (.class files) are contained in the bin/ folder. Note that these have only been provided as another way of running the application. 