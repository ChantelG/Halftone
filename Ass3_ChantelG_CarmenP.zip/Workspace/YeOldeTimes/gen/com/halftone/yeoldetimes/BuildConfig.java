/** Automatically generated file. DO NOT MODIFY */
package com.halftone.yeoldetimes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}